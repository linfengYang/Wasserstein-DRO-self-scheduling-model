% ����mosek����ģ
clear all
clc

FileName = 'SCUC_dat/SCUC118_24period.txt';
SCUC_data = ReadDataSCUC(FileName);

%% ���ò���
L = 4; %�����Ĳ������������Ի��������
fname = regexp(FileName, '\d*', 'match');
beta_CVaR = 0.95;
type_of_pf = 'DC';
eta = 0.95;

T = SCUC_data.totalLoad.T;  % ʱ����T
G = SCUC_data.units.N;      % �������
N = SCUC_data.baseparameters.busN;  % �ڵ�����
all_branch.I = [ SCUC_data.branch.I; SCUC_data.branchTransformer.I ]; %����֧·��� ǰ��֧·��� ���Ǳ�ѹ��֧·���
all_branch.J = [ SCUC_data.branch.J; SCUC_data.branchTransformer.J ]; %����֧·�յ�
all_branch.P = [ SCUC_data.branch.P; SCUC_data.branchTransformer.P ]; %֧·��������



%% ���ɵ�ۺ͵��ɾ���
% MonteCarlo_Price(SCUC_data,FileName); %Ҫ����lamda_q_NTʱ�ٴ򿪣���Ȼ�˷�ʱ�� load
load (sprintf('lamda_q_%sN%sTtest',fname{1,1},fname{1,2}))
% �γ�ֱ������ϵ������B
Y = SCUC_nodeY(SCUC_data,type_of_pf);
B = -Y.B; %��Ϊ��ֱ������ ����B�����˵��� ֻ���ǵ翹

q=q_line;
varnum = 2*G*T+N*T+q+2+2*G*T*q*2+G*T*q*2+q*2;


%% ����֧�ż�
% ������ȡ��۵�����GT*q_line
price = zeros(G*T,q_line);
for i = 1:q 
    temp = reshape(lamda_q_NT(i,:,:),G,T);
    temp = reshape(temp',G*T,1);
    price(:,i) = temp;
end
% �����ֵ��Э����
miu_hat = mean(price,2);
% temp = price  - repmat(miu_hat,1,q_line );
% a =1/q_line*(temp*temp');
Sigma_hat = cov(price')*(q-1)/q;
Sigma_hat_half = Sigma_hat^(1/2);
% ����֧�ż�S G*Tά������������ÿ��G����ʱ������
%��С���֧�ż�
lamda_positive = max(price,[],2) ;
lamda_negative = min(price,[],2) ;
A = [sparse(1:G*T,1:G*T,1); -sparse(1:G*T,1:G*T,1)];
B_set = [lamda_positive; -lamda_negative ];


%% ��ģ�����뾶
rho = sdpvar(1);
sum_C = sum(exp(rho * sum(abs(price - miu_hat),1).^2));
sum_C = sum_C / q;
obj_C = 1 + log(sum_C);
Constraints_C =  rho >= 0;
Objective_C = 2 *  ( ((1 / (2 * rho)) * obj_C) ^(1/2) );
options_C = sdpsettings('solver','fmincon','verbose',0,'debug',1,'savesolveroutput',1);%, 'fmincon.TolX',1e-4
sol_C = optimize(Constraints_C,Objective_C,options_C);
C = sol_C.solveroutput.fmin;
mid_eps = log( 1 / (1-eta));
mid_eps = mid_eps / q;
eps = C * sqrt(mid_eps); 
eps = eps/120;
% % end of ����eps
%% ��ģ
% Ŀ���е�������
prob.c = sparse( [sparse( 2*G*T+N*T, 1 ); ones(q, 1);0; eps; sparse(2*G*T*q*2+G*T*q*2+q*2, 1)] );

temp =(-A*price+B_set)';
temp =mat2cell(temp,ones(1,q),2*G*T);
temp = sparse(blkdiag(temp{:}));

a1 = sparse( [sparse(q,(2*G+N)*T), -q*speye(q), ones(q,1), sparse(q,1), temp, sparse(q,2*G*T*q+G*T*q*2+q*2)] );  
blc_a1 = -inf*ones(q,1);
buc_a1 = sparse(q,1);


a2 = sparse([-1/(1-beta_CVaR)*price', sparse(q,N*T), 1/(1-beta_CVaR)*ones(q,G*T), -q*speye(q), -beta_CVaR/(1-beta_CVaR)*ones(q,1), sparse(q,1+2*G*T*q), temp, sparse(q,G*T*q*2+q*2)]);
blc_a2 = -inf*ones(q,1);
buc_a2 = sparse(q,1);


a_w = sparse([ sparse(q*2, 2*G*T+N*T+q+1), -1*ones(q*2,1), sparse(q*2, 2*G*T*q*2+G*T*q*2), speye(q*2) ]) ;
blc_w = sparse(q*2,1);
buc_w = sparse(q*2,1);

temp1 = A';
temp1=repmat(temp1,q,1);
temp1 =mat2cell(temp1,G*T*ones(1,q),2*G*T);
temp1 = sparse(blkdiag(temp1{:}));
a_f = sparse( [sparse(G*T*q, 2*G*T+N*T+q+2), temp1, sparse(G*T*q, 2*G*T*q), speye(G*T*q), sparse(G*T*q, G*T*q+q*2)] );
blc_f = sparse(q*G*T,1);
buc_f =sparse(q*G*T,1);

[rcode,res1] = mosekopt('symbcon echo(0)');
prob.f = [];
prob.g = [];
prob.cones = [];
for  i=1:q
    tmp1 = zeros(G*T, G*T*q);
    tmp1(:, (i-1)*G*T+1:i*G*T) = eye(G*T);
    tmp2 = zeros(1,q*2);
    tmp2(i)=1;
    prob.f = sparse([prob.f ;
            sparse(1,varnum-q*2), tmp2;
            sparse(G*T,2*G*T+N*T+q+2+2*G*T*q*2), sparse(tmp1), sparse(G*T,G*T*q+q*2);]);
    prob.g = [prob.g; zeros(G*T+1,1)];
    prob.cones = [prob.cones, res1.symbcon.MSK_CT_QUAD G*T+1];
end



a_g = sparse( [ repmat(1/(1-beta_CVaR)*eye(G*T),q,1), sparse(G*T*q, N*T+G*T+q+2+2*G*T*q), temp1, sparse(G*T*q, G*T*q), speye(G*T*q), sparse(G*T*q,q*2)] );
blc_g = sparse(q*G*T,1);
buc_g = sparse(q*G*T,1);

for  i=1:q
    tmp1 = zeros(G*T, G*T*q);
    tmp1(:, (i-1)*G*T+1:i*G*T) = eye(G*T);
    tmp2 = zeros(1,q*2);
    tmp2(q+i)=1;
    prob.f = sparse([prob.f ;
        sparse(1,varnum-q*2), tmp2;
        sparse(G*T,2*G*T+N*T+q+2+2*G*T*q*2+G*T*q), sparse(tmp1), sparse(G*T,q*2);]);
    prob.g = [prob.g; zeros(G*T+1,1)];
    prob.cones = [prob.cones, res1.symbcon.MSK_CT_QUAD G*T+1];
end

a_output = sparse([speye(G*T), sparse(G*T, varnum-G*T) ]);
blc_output  = repelem(SCUC_data.units.PG_low, T);
buc_output  = repelem(SCUC_data.units.PG_up, T);

temp = sparse(eye(T));%T*T�ĶԽ��󣬶Խ���ȫ1
temp = temp(2:T,:) - temp(1:T-1,:); 
temp=repmat(temp,G,1);
temp =mat2cell(temp,(T-1)*ones(1,G),T);
temp = blkdiag(temp{:});
a_rampup = sparse([temp, sparse( (T-1)*G, varnum-G*T)]);
blc_rampup = -inf*ones((T-1)*G,1);
buc_rampup = repelem(SCUC_data.units.ramp, T-1);

a_rampdown = sparse([-temp, sparse( (T-1)*G, varnum-G*T)]);
blc_rampdown  = -inf*ones((T-1)*G,1);
buc_rampdown  = repelem(SCUC_data.units.ramp, T-1);

temp = zeros(T,N*T);
temp(:, (SCUC_data.baseparameters.balanceBus-1)*T+1:SCUC_data.baseparameters.balanceBus*T) = speye(T);
a_ref = sparse( [sparse(T,G*T),temp, sparse(T,varnum-G*T-N*T)] );
blc_ref  = sparse(T,1);
buc_ref = sparse(T,1);

a_dc = [];
buc_dc=[];
blc_dc=[];
for i=1:N
    temp1 = zeros(T, G*T);
    if ismember(i, SCUC_data.units.bus_G)
        index = find(SCUC_data.units.bus_G==i);
        temp1(:,(index-1)*T+1:index*T) = eye(T);
    end  
    temp2 = repmat(speye(T),1,N);
    tmp = repelem(-B(i,:),T);
    temp2 =temp2.*tmp;
    a_dc = sparse([ a_dc; [sparse(temp1), sparse(temp2), sparse(T,varnum-G*T-N*T) ] ]);
    index = find(SCUC_data.busLoad.bus_PDQR==i);
    if index>0
        buc_dc=[buc_dc; SCUC_data.busLoad.node_P(:,index)];
    else
        buc_dc=[buc_dc; sparse(T,1)];
    end
end
blc_dc = sparse( N*T,1);

a_line = [];
blc_line  = [];
buc_line = [];
for i = 1:size(all_branch.I,1)
    left = all_branch.I(i); 
    right = all_branch.J(i);
    temp = zeros(T,N*T);
    temp(:,(left-1)*T+1:left*T) = eye(T);
    temp(:,(right-1)*T+1:right*T) = -eye(T);
    a_line =sparse([a_line; [sparse(T, G*T), sparse(temp), sparse(T, varnum-G*T-N*T)] ]);
    temp = all_branch.P(i) * abs(-1/B(left,right)); 
    blc_line  = [blc_line;  -temp* ones(T,1)];
    buc_line = [buc_line; temp* ones(T,1)];
end

a_z = [];
buc_z = [];
for l=0:L-1
    p_l = SCUC_data.units.PG_low + ( SCUC_data.units.PG_up - SCUC_data.units.PG_low ) / L * l;
    temp = 2* p_l .* SCUC_data.units.gamma+SCUC_data.units.beta;
    temp = repelem(temp,T);
    temp2 = SCUC_data.units.alpha - (p_l .^2).* SCUC_data.units.gamma;
    temp2 = repelem(temp2,T);
    a_z = sparse([a_z; [diag(temp), sparse(G*T,N*T), -speye(G*T), sparse(G*T, varnum-2*G*T-N*T) ] ]);
    buc_z = [buc_z; -temp2 ];
end
blc_z = -inf*ones(G*T*L,1);
prob.a = sparse([a1; a2; a_w; a_f; a_g; a_output; a_rampup; a_rampdown; a_ref; a_line; a_dc; a_z]);
prob.blc = sparse([blc_a1; blc_a2; blc_w; blc_f; blc_g; blc_output; blc_rampup; blc_rampdown; blc_ref; blc_line; blc_dc; blc_z]);
prob.buc = sparse([buc_a1; buc_a2; buc_w; buc_f; buc_g; buc_output; buc_rampup; buc_rampdown; buc_ref; buc_line; buc_dc; buc_z]);

% �������½�
prob.blx =[-inf*ones(2*G*T+N*T+q+1,1); zeros(1+2*G*T*q*2,1); -inf*ones(G*T*q*2,1); zeros(q*2,1)];%0; -inf*ones(,1)
prob.bux =inf*ones(varnum,1);
param.MSK_IPAR_INTPNT_MAX_ITERATIONS = 100;
[~,res]  = mosekopt('minimize echo(0)', prob,param);%,param echo(0) log(moseklog.txt) write(original.opf)

P = res.sol.itr.xx(1:G*T);
theta = res.sol.itr.xx(G*T+1:G*T+N*T);
z = res.sol.itr.xx(G*T+N*T+1:G*T+N*T+G*T);
v = res.sol.itr.xx(G*T+N*T+G*T+1:G*T+N*T+G*T+q);
alpha_CVaR = res.sol.itr.xx(G*T+N*T+G*T+q+1);
omega = res.sol.itr.xx(G*T+N*T+G*T+q+2);
r = res.sol.itr.xx(G*T+N*T+G*T+q+2+1:G*T+N*T+G*T+q+2+2*G*T*q );
s =res.sol.itr.xx(G*T+N*T+G*T+q+2+2*G*T*q+1:G*T+N*T+G*T+q+2+2*G*T*q+2*G*T*q);
f = res.sol.itr.xx(2*G*T+N*T+q+2+2*G*T*q*2+1:2*G*T+N*T+q+2+2*G*T*q*2+G*T*q);
g = res.sol.itr.xx(2*G*T+N*T+q+2+2*G*T*q*2+G*T*q+1:2*G*T+N*T+q+2+2*G*T*q*2+G*T*q*2);
% r = reshape(res.sol.itr.xx(G*T+N*T+G*T+q+2+1:G*T+N*T+G*T+q+2+2*G*T*q ), 2*G*T,q);
% s =reshape(res.sol.itr.xx(G*T+N*T+G*T+q+2+2*G*T*q+1:G*T+N*T+G*T+q+2+2*G*T*q+2*G*T*q), 2*G*T,q);
% f = reshape(res.sol.itr.xx(2*G*T+N*T+q+2+2*G*T*q*2+1:2*G*T+N*T+q+2+2*G*T*q*2+G*T*q), G*T,q);
% g = reshape(res.sol.itr.xx(2*G*T+N*T+q+2+2*G*T*q*2+G*T*q+1:2*G*T+N*T+q+2+2*G*T*q*2+G*T*q*2), G*T,q);
omega1_2q = res.sol.itr.xx(2*G*T+N*T+q+2+2*G*T*q*2+G*T*q*2+1:2*G*T+N*T+q+2+2*G*T*q*2+G*T*q*2+q*2);

obj = sum(v)+eps * omega;
profit =100*(P'* miu_hat - sum(z)) ;
total_PDt = SCUC_data.totalLoad.PD_T*100;
PGit = P*100;
PGit = reshape(PGit,T,G);
total_PGt =  sum(PGit,2);
theta = reshape(theta,T,N);
netloss = sum(theta*B*100,2);
disp('obj= ');
disp(obj);
disp('profit = ');
disp(profit);
disp('alpha_CVaR = ');
disp(alpha_CVaR);

figure(1);
x = 1 : str2num(fname{1,2});
plot( (total_PDt+netloss)' ,'.-r');
str1=num2str(total_PDt+netloss);
text(x,(total_PDt+netloss)',str1);
hold on 
bar(x,total_PGt); %[total_PGt netlosst],'stacked'
str2=num2str(total_PGt);
text(x,total_PGt',str2,'HorizontalAlignment','center',...
        'VerticalAlignment','bottom','FontSize',8);
line([0,size(x,2)+1],[sum(SCUC_data.units.PG_low)*100,sum(SCUC_data.units.PG_low)*100],'linestyle','--');
title('�ܳ������');
xlabel('ʱ��');  
ylabel('����');
% axis([-inf, inf, 0,260]);
hold off
