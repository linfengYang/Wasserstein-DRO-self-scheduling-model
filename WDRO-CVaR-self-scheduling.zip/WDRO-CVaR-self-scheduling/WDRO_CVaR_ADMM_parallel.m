clear all
clc
tic
FileName = 'SCUC_dat/SCUC118_24period.txt';
SCUC_data = ReadDataSCUC(FileName);

%% ���ò���
L = 4; %�����Ĳ������������Ի��������
fname = regexp(FileName, '\d*', 'match');
beta_CVaR = 0.95;
type_of_pf = 'DC';
eta = 0.95;

T = SCUC_data.totalLoad.T;  % ʱ����T
G = SCUC_data.units.N;      % �������
N = SCUC_data.baseparameters.busN;  % �ڵ�����
all_branch.I = [ SCUC_data.branch.I; SCUC_data.branchTransformer.I ]; %����֧·��� ǰ��֧·��� ���Ǳ�ѹ��֧·���
all_branch.J = [ SCUC_data.branch.J; SCUC_data.branchTransformer.J ]; %����֧·�յ�
all_branch.P = [ SCUC_data.branch.P; SCUC_data.branchTransformer.P ]; %֧·��������



%% ���ɵ�ۺ͵��ɾ���
% MonteCarlo_Price(SCUC_data,FileName); %Ҫ����lamda_q_NTʱ�ٴ򿪣���Ȼ�˷�ʱ�� load
load (sprintf('lamda_q_%sN%sTtest',fname{1,1},fname{1,2}))
Y = SCUC_nodeY(SCUC_data,type_of_pf);
B = -Y.B; 

q=q_line;
diag_E_T = sparse(eye(T)); %T*T�ĶԽ��󣬶Խ���ȫ1
low_trianle = diag_E_T(2:T,:) - diag_E_T(1:T-1,:);

%% ��ȡ��۵�����GT*q_line
price = zeros(G*T,q_line);
for i = 1:q
    temp = reshape(lamda_q_NT(i,:,:),G,T);
    temp = reshape(temp',G*T,1);
    price(:, i) = temp;
end
miu_hat = mean(price,2);

%% ���򻮷�
[ PI,PINum,PIGNum,PIG ] = partition_matrix( N );
D = length(PI);     %������
varnum = cell(D,1);
for d=1:D
    varnum{d} =2*PIGNum{d}*T+PINum{d}*T+q+2+2*PIGNum{d}*T*q*2+PIGNum{d}*T*q*2+2*q+1;
end
[data_Partition] = function_NodeDataPartition(SCUC_data,PI,B);
%% �жϽڵ����ڽڵ㻹����ڵ�
extnode = [];
for d = 1:D
    for i = 1:size(all_branch.I,1)
        left = all_branch.I(i); 
        right = all_branch.J(i);
        if ismember(left, PI{d}') && ~ismember(right, PI{d}') 
            extnode = [extnode;left;right];
        end
    end
end
extnode = unique(extnode);
[rcode,res1] = mosekopt('symbcon echo(0)');
%% ����p��Լ��
prob_p = cell(D,1);
A = cell(D,1);
B_set = cell(D,1);
price_d = cell(D,1);
eps = zeros(D,1);
rho_admm =10;
parfor d =1:D
    PIi = PI{d};    %��ȡd����Ļ�����
    PIN = PINum{d};  %d���������
    GNum = PIGNum{d};   %d���򷢵������
    GNo = PIG{d};   %d���򷢵������
    
    for i=PIi'
        if ismember(i, SCUC_data.units.bus_G)
            Gnode_index= find(SCUC_data.units.bus_G == i);
            price_d{d} = [price_d{d};price( (Gnode_index-1)*T+1:Gnode_index*T,: )];
        end
    end
    % ��������֧�ż�
    lamda_positive_d = max(price_d{d},[],2) ;
    lamda_negative_d = min(price_d{d},[],2) ;
    A{d} = [sparse(1:GNum*T,1:GNum*T,1); -sparse(1:GNum*T,1:GNum*T,1)];
    B_set{d} = [lamda_positive_d; -lamda_negative_d ];
    
    % ��������ģ����
    miu_hat_d = mean( price_d{d} , 2);
    rho_d = sdpvar(1);
    sum_C_d  = sum(exp(rho_d * sum(abs(price_d{d} - miu_hat_d),1).^2));
    sum_C_d = sum_C_d / q;
    obj_C_d = 1 + log(sum_C_d);
    Constraints_C_d = rho_d >= 0;
    Objective_C_d =  2 * ( ((1 / (2 * rho_d)) * obj_C_d) ^(1/2) );
    options_C_d = sdpsettings('solver','fmincon','verbose',0,'debug',1,'savesolveroutput',1);%, 'fmincon.TolX',1e-4
    sol_C_d = optimize(Constraints_C_d,Objective_C_d,options_C_d);
    C_d = sol_C_d.solveroutput.fmin;
    mid_eps = log( 1 / (1-eta));
    mid_eps = mid_eps / q_line;
    eps(d) = C_d * sqrt(mid_eps);
    eps(d)= eps(d)/120;
    
                                                                                                                                                                                                                                                                                                                                                                                ��׶, ����Լ��t = p'p
    prob_p{d}.f = [];
    prob_p{d}.g = [];
    prob_p{d}.cones = [];
    prob_p{d}.f = sparse([prob_p{d}.f;...
        zeros(1,varnum{d}-1), 1;...
        zeros(1,varnum{d})      ;...
        eye(GNum*T+PIN*T), zeros(GNum*T+PIN*T,varnum{d}-GNum*T-PIN*T)]);
    prob_p{d}.g = [prob_p{d}.g; 0; 0.5; zeros(GNum*T+PIN*T,1)];
    prob_p{d}.cones = [prob_p{d}.cones, res1.symbcon.MSK_CT_RQUAD GNum*T+PIN*T+2];
    

    temp =(-A{d}*price_d{d}+B_set{d})';
    temp =mat2cell(temp,ones(1,q),2*GNum*T);
    temp = sparse(blkdiag(temp{:}));
    a1 = sparse([sparse(q,2*GNum*T+PIN*T), -q*speye(q), ones(q,1), sparse(q,1), temp, sparse(q,2*GNum*T*q+GNum*T*q*2+2*q+1)]);
    blc_a1 = -inf*ones(q,1);
    buc_a1 = sparse(q,1);
    

    a2 = sparse([-1/(1-beta_CVaR)*price_d{d}', sparse(q,PIN*T), 1/(1-beta_CVaR)*ones(q, GNum*T), -q*speye(q), -beta_CVaR/(1-beta_CVaR)*ones(q,1), sparse(q,1+2*GNum*T*q), temp, sparse(q,GNum*T*q*2+2*q+1)]);
    blc_a2 = -inf*ones(q,1);
    buc_a2 = sparse(q,1);

    a_w = sparse([ sparse(q*2, 2*GNum*T+PIN*T+q+1), -1*ones(q*2,1), sparse(q*2, 2*GNum*T*q*2+GNum*T*q*2), speye(q*2), sparse(q*2,1)]) ;
    blc_w = sparse(q*2,1);
    buc_w = sparse(q*2,1);

    temp1 = A{d}';
    temp1=repmat(temp1,q,1);
    temp1 =mat2cell(temp1,GNum*T*ones(1,q),2*GNum*T);
    temp1 = sparse(blkdiag(temp1{:}));
    a_f = sparse( [sparse(GNum*T*q, 2*GNum*T+PIN*T+q+2), temp1, sparse(GNum*T*q, 2*GNum*T*q), speye(GNum*T*q), sparse(GNum*T*q, GNum*T*q+2*q+1)] );
    blc_f = sparse(q*GNum*T,1);
    buc_f =sparse(q*GNum*T,1);

    a_g = sparse( [ repmat(1/(1-beta_CVaR)*eye(GNum*T),q,1), sparse(GNum*T*q, PIN*T+GNum*T+q+2+2*GNum*T*q), temp1, sparse(GNum*T*q, GNum*T*q), speye(GNum*T*q), sparse(GNum*T*q, 2*q+1)] );
    blc_g = sparse(q*GNum*T,1);
    buc_g = sparse(q*GNum*T,1);
    

    temp1 = [1 ;sparse(GNum*T,1)];
    temp1 = repmat(temp1,q,1);
    temp1 = mat2cell(temp1,(GNum*T+1)*ones(1,q),1);
    temp1 = blkdiag(temp1{:});
    temp2 = [sparse(1,GNum*T); speye(GNum*T)];
    temp2 = repmat(temp2,q,1);
    temp2 = mat2cell(temp2,(GNum*T+1)*ones(1,q),GNum*T);
    temp2 = blkdiag(temp2{:});
    prob_p{d}.f = sparse([prob_p{d}.f;...
        [sparse((1+GNum*T)*q,2*GNum*T+PIN*T+q+2+2*GNum*T*q*2), temp2, sparse((1+GNum*T)*q,GNum*T*q), temp1, sparse((1+GNum*T)*q,q+1)] ]);
    prob_p{d}.g = [prob_p{d}.g; zeros((1+GNum*T)*q,1)];
    prob_p{d}.cones = [prob_p{d}.cones, repmat([res1.symbcon.MSK_CT_QUAD 1+GNum*T],1,q)];
    

    prob_p{d}.f = sparse([prob_p{d}.f;...
        [sparse((1+GNum*T)*q,2*GNum*T+PIN*T+q+2+2*GNum*T*q*2+GNum*T*q), temp2, sparse((1+GNum*T)*q,q), temp1, sparse((1+GNum*T)*q, 1)]]);
    prob_p{d}.g = [prob_p{d}.g; zeros((1+GNum*T)*q,1)];
    prob_p{d}.cones = [prob_p{d}.cones, repmat([res1.symbcon.MSK_CT_QUAD 1+GNum*T],1,q)];
    

    a_output  = sparse( [speye(GNum*T), sparse(GNum*T,varnum{d}-GNum*T)] );
    blc_output  = repelem(data_Partition{d}.units.PG_low, T)';
    buc_output  = repelem(data_Partition{d}.units.PG_up, T)';

    temp = sparse(eye(T));%T*T�ĶԽ��󣬶Խ���ȫ1
    temp = temp(2:T,:) - temp(1:T-1,:);
    temp=repmat(temp,GNum,1);
    temp =mat2cell(temp,(T-1)*ones(1,GNum),T);
    temp = blkdiag(temp{:});
    a_rampup = sparse([temp, sparse( (T-1)*GNum, varnum{d}-GNum*T)]);
    blc_rampup = -inf*ones((T-1)*GNum,1);
    buc_rampup = repelem(data_Partition{d}.units.Piup, T-1)';
    
    a_rampdown = sparse([-temp, sparse( (T-1)*GNum, varnum{d}-GNum*T)]);
    blc_rampdown  = -inf*ones((T-1)*GNum,1);
    buc_rampdown  = repelem(data_Partition{d}.units.Pidown, T-1)';

    a_ref = [];
    blc_ref  = [];
    buc_ref = [];
    index = find(PIi==SCUC_data.baseparameters.balanceBus);
    if index
        temp = zeros(T,PIN*T);
        temp(:, (index-1)*T+1:index*T) = speye(T);
        a_ref = sparse( [sparse(T,GNum*T), temp, sparse(T,varnum{d}-GNum*T-PIN*T)] );
        blc_ref  = sparse(T,1);
        buc_ref = sparse(T,1);
    end

    a_z = [];
    buc_z = [];
    for l=0:L-1
        p_l = data_Partition{d}.units.PG_low + ( data_Partition{d}.units.PG_up - data_Partition{d}.units.PG_low ) / L * l;
        temp = 2*data_Partition{d}.units.gamma.*p_l + data_Partition{d}.units.beta ;
        temp = repelem(temp, T)';
        a_z = sparse([a_z; [sparse(diag(temp)), sparse(GNum*T,PIN*T), -speye(GNum*T), sparse(GNum*T,varnum{d}-2*GNum*T-PIN*T)]]);
        temp = data_Partition{d}.units.gamma.*(p_l.^2)-data_Partition{d}.units.alpha ;
        temp = repelem(temp, T)';
        buc_z = [buc_z; temp];
    end
    blc_z = -inf*ones(GNum*T*L,1);
    
    prob_p{d}.a = sparse([a1; a2; a_w; a_f; a_g; a_output; a_rampup; a_rampdown; a_ref; a_z]);%
    prob_p{d}.blc = sparse([blc_a1; blc_a2; blc_w; blc_f; blc_g; blc_output; blc_rampup; blc_rampdown; blc_ref; blc_z]);%
    prob_p{d}.buc = sparse([buc_a1; buc_a2; blc_w; buc_f; buc_g; buc_output; buc_rampup; buc_rampdown; buc_ref; buc_z]);%
    prob_p{d}.blx =[-inf*ones(GNum*T+PIN*T+GNum*T+q+1,1); zeros(1+2*GNum*T*q*2,1); -inf*ones(GNum*T*q*2,1); zeros(q*2+1,1)];%0; -inf*ones(,1)
    prob_p{d}.bux =inf*ones(varnum{d},1);
    % Ŀ������
    prob_p{d}.c = sparse( [sparse( GNum*T+PIN*T+GNum*T, 1 ); ones(q, 1); 0; eps(d); sparse(2*GNum*T*q*2+GNum*T*q*2+2*q, 1); rho_admm/2] );%rho_admm/2
    
end

%% ����z��Լ��
prob_z.a = [];
prob_z.blc = [];
prob_z.buc = [];

a_line = [];  %��ÿ����·����Լ����ÿ����·Ӧ����T��Լ��
blc_line  = [];
buc_line = [];
for i = 1:size(all_branch.I,1) %�ӵ�һ��֧·��ʼѭ����������֧·
    left = all_branch.I(i); %֧·�����յ㼴�ɵõ�B����
    right = all_branch.J(i);
    temp = zeros(T,N*T);
    temp(:,(left-1)*T+1:left*T) = eye(T);
    temp(:,(right-1)*T+1:right*T) = -eye(T);
    a_line =sparse([a_line; [sparse(T, G*T), sparse(temp)] ]);
    temp = all_branch.P(i) * abs(-1/B(left,right));
    blc_line  = [blc_line;  -temp* ones(T,1)];
    buc_line = [buc_line; temp* ones(T,1)];
end
prob_z.a = [prob_z.a; a_line; ];
prob_z.blc = [prob_z.blc;  blc_line;];
prob_z.buc = [prob_z.buc; buc_line;];

for d =1:D
    
    PIi = PI{d};    %��ȡd����Ļ�����
    PIN = PINum{d};  %d���������
    GNum = PIGNum{d};   %d���򷢵������
    GNo = PIG{d};   %d���򷢵������
    
    % dcԼ��
    a_dc = [];
    blc_dc = [];
    buc_dc=[];
    for i=PI{d}'
        temp1 = zeros(T, G*T);
        if ismember(i, SCUC_data.units.bus_G)
            index = find(SCUC_data.units.bus_G==i);
            temp1(:,(index-1)*T+1:index*T) = eye(T);
        end
        temp2 = repmat(speye(T),1,N);
        tmp = repelem(-B(i,:),T);
        temp2 =temp2.*tmp;
        a_dc = sparse([ a_dc; [sparse(temp1), sparse(temp2) ] ]);
        index = find(SCUC_data.busLoad.bus_PDQR==i);
        if index>0
            buc_dc=[buc_dc; SCUC_data.busLoad.node_P(:,index)];
        else
            buc_dc=[buc_dc; sparse(T,1)];
        end
        blc_dc = [blc_dc; sparse(T,1)];
    end
    
    prob_z.a = [prob_z.a; a_dc;]; %a_line;
    prob_z.blc = [prob_z.blc;   blc_dc;];%blc_line;
    prob_z.buc = [prob_z.buc; buc_dc;];   % buc_line;
    
end
prob_z.blx = -inf*ones(G*T+N*T,1);
prob_z.bux = inf*ones(G*T+N*T,1);

temp_z_a = [];
temp_p = prob_z.a(:,1:G*T);
temp_theta = prob_z.a(:,G*T+1:G*T+N*T);
for d=1:D
    PIi = PI{d};    %��ȡd����Ļ�����
    PIN = PINum{d};  %d���������
    GNum = PIGNum{d};   %d���򷢵������
    GNo = PIG{d};   %d���򷢵������
    
    temp = ismember(SCUC_data.units.bus_G, GNo);
    temp = repelem(temp,T);
    temp_z_a=[temp_z_a, temp_p(:,temp==1)];
    temp = ismember(1:N, PIi);
    temp = repelem(temp,T);
    temp_z_a=[temp_z_a, temp_theta(:,temp==1)];
    
end
prob_z.a = temp_z_a;
prob_z.q = rho_admm*eye(G*T+N*T);

toc
%% ADMM����
solvertime =0;
M = 200;                % ��������
gap_pri =5e-1;
gap_dual =5e-1;
array_pri = zeros(M,1);
array_dual  = zeros(M,1);
p = cell(D,1);
z = cell(D,1);
theta  = cell(D,1);
v = zeros(D,q_line);
omega = zeros(D,1);
alpha_CVaR=zeros(D,1);
r = cell(D,1);
s = cell(D,1);
total_sol = cell(D,1);
z_A_k = sparse(G*T+N*T,1);
u_A_k = sparse(G*T+N*T,1);
tic
for k=1:M
    %% p-update
    p_A_k1=[];
    kstarttime = clock;
    parfor d  = 1:D    %������ģ
        PIN = PINum{d};  %d���������
        GNum = PIGNum{d};   %d���򷢵������
        [z_A_d_k, u_A_d_k] = divide_G_N(d, z_A_k, u_A_k, N);
        
        % Ŀ���е�������
        prob_p{d}.c(1:GNum*T+PIN*T) = rho_admm*(-z_A_d_k+u_A_d_k);        
        
        [~,res]  = mosekopt('minimize info echo(0)', prob_p{d});%write(dump.opf),param
        p_A_d_k = [res.sol.itr.xx(1:GNum*T); res.sol.itr.xx(GNum*T+1:GNum*T+PIN*T)];
        p_A_k1 = [p_A_k1; p_A_d_k];
        p{d} = res.sol.itr.xx(1:GNum*T);
        theta{d} = res.sol.itr.xx(GNum*T+1:GNum*T+PIN*T);
        z{d} = res.sol.itr.xx(GNum*T+PIN*T+1:GNum*T+PIN*T+GNum*T);
        v(d,:) = res.sol.itr.xx(GNum*T+PIN*T+GNum*T+1:GNum*T+PIN*T+GNum*T+q);
        alpha_CVaR(d) = res.sol.itr.xx(GNum*T+PIN*T+GNum*T+q+1);
        omega(d) = res.sol.itr.xx(GNum*T+PIN*T+GNum*T+q+2);
%         r{d} = res.sol.itr.xx(GNum*T+PIN*T+GNum*T+q+3:GNum*T+PIN*T+GNum*T+q+2+2*GNum*T*q );
%         s{d} = res.sol.itr.xx(GNum*T+PIN*T+GNum*T+q+2+2*GNum*T*q+1:GNum*T+PIN*T+GNum*T+q+2+2*GNum*T*q*2);
%         total_sol{d} = res.sol.itr.xx;
    end
    kendtime=clock;
    steptime = etime(kendtime,kstarttime);
    
    %% z-update
    prob_z.c = -rho_admm*(p_A_k1+u_A_k)';
    [res] = mskqpopt(prob_z.q, prob_z.c, prob_z.a, prob_z.blc, prob_z.buc, prob_z.blx, prob_z.bux,[],'minimize echo(0) info');%write(dump.opf)
    solvertime = solvertime+steptime+ res.info.MSK_DINF_OPTIMIZER_TIME;
    z_A_k1 = res.sol.itr.xx;
    
    %% u-update
    u_A_k1 = u_A_k + (p_A_k1-z_A_k1);
    
    %% �ж��˳�
    pri  = norm(p_A_k1-z_A_k1);
    dual =  rho_admm*norm(z_A_k-z_A_k1);
    array_pri(k) = pri;
    array_dual(k) = dual;
    if ( pri <= gap_pri) && ( dual <= gap_dual)&&k>1
        disp('ADMM over');
        break
    end
    fprintf('�� %d ��ѭ��. pri_gap : %d, dual_gap : %d\n',k,pri,dual);
    %% ��¼���ε�����������´ε���
    z_A_k = z_A_k1;
    u_A_k = u_A_k1;
end
toc
time = toc;
obj = sum(sum(v))+sum(eps .* omega);
Nop = [];
Notheta = [];
P_vector = []; %����[p11 p12 ...p1t;p21...p2t...pnt]��������
theta_vector = [];
z_vector = [];
for d = 1:D
    Nop = [Nop; PIG{d}];
    Notheta = [Notheta; PI{d}];
    P_vector = [P_vector; p{d}]; %��������;�ָ�
    theta_vector = [theta_vector; theta{d}];
    z_vector = [z_vector; z{d}];
end
[~,Ip] = sort(repelem(Nop,T));
[~,Itheta] = sort(repelem(Notheta,T));
P_vector = P_vector(Ip);
theta_vector = theta_vector(Itheta);
z_vector = z_vector(Ip);
profit =100*(P_vector'* miu_hat - sum(z_vector)) ;
total_PDt = SCUC_data.totalLoad.PD_T*100;
PGit = P_vector*100;
PGit = reshape(PGit,T,G);
total_PGt =  sum(PGit,2);
theta= reshape(theta_vector,T,N);
netloss = sum(theta*B*100,2);
disp('obj= ');
disp(obj);
disp('profit = ');
disp(profit);

figure(1);
x = 1 : str2num(fname{1,2});
plot( (total_PDt+netloss)' ,'.-r');%
str1=num2str(total_PDt+netloss);%
text(x,(total_PDt+netloss)',str1);%
hold on
bar(x,total_PGt); %[total_PGt netlosst],'stacked'
str2=num2str(total_PGt);
text(x,total_PGt',str2,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom','FontSize',8);
line([0,size(x,2)+1],[sum(SCUC_data.units.PG_low)*100,sum(SCUC_data.units.PG_low)*100],'linestyle','--');
title('�ܳ������');
xlabel('ʱ��');
ylabel('����');
% axis([-inf, inf, 0,260]);
hold off

figure(2);
plot(array_dual)
hold on
plot(array_pri)
legend('dual','pri')
hold off

