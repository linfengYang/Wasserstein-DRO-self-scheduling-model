function [ z_A_d_k, u_A_d_k ] = divide_G_N( d, z_A_k, u_A_k, N )
%DIVIDE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% ����������ȡz_A_d_k, u_A_d_k
%Լ�����
T =24;
if N==6
%     % 1��
%     switch d
%         case 1
%             u_A_d_k= u_A_k(1 : (9*T));
%             z_A_d_k= z_A_k(1 : (9*T));
%     end
    % 2��
    switch d
        case 1
            u_A_d_k= u_A_k(1 : (5*T));
            z_A_d_k= z_A_k(1 : (5*T));
        case 2
            u_A_d_k = u_A_k((5*T)+1 : 9*T);
            z_A_d_k = z_A_k((5*T)+1 : 9*T);
    end
    
elseif N==30
    % 1��
%     switch d
%         case 1
%             u_A_d_k= u_A_k(1 : (36*T));
%             z_A_d_k= z_A_k(1 : (36*T));
%     end
    % 2��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (18*T));
%             z_A_d_k = z_A_k(1 : (18*T));
%         case 2
%             u_A_d_k = u_A_k((18*T)+1 : 36*T);
%             z_A_d_k = z_A_k((18*T)+1 : 36*T);
%     end
    % 3��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (12*T));
%             z_A_d_k = z_A_k(1 : (12*T));
%         case 2
%             u_A_d_k = u_A_k((12*T)+1 : 24*T);
%             z_A_d_k = z_A_k((12*T)+1 : 24*T);
%         case 3
%             u_A_d_k = u_A_k((24*T)+1 : 36*T);
%             z_A_d_k = z_A_k((24*T)+1 : 36*T);
%     end
    % 4��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (6*T));
%             z_A_d_k = z_A_k(1 : (6*T));
%         case 2
%             u_A_d_k = u_A_k((6*T)+1 : 18*T);
%             z_A_d_k = z_A_k((6*T)+1 : 18*T);
%         case 3
%             u_A_d_k = u_A_k((18*T)+1 : 28*T);
%             z_A_d_k = z_A_k((18*T)+1 : 28*T);
%         case 4
%             u_A_d_k = u_A_k((28*T)+1 : 36*T);
%             z_A_d_k = z_A_k((28*T)+1 : 36*T);
%     end

    % 6��
    switch d
        case 1
            u_A_d_k = u_A_k(1 : (6*T));
            z_A_d_k = z_A_k(1 : (6*T));
        case 2
            u_A_d_k = u_A_k((6*T)+1 : 12*T);
            z_A_d_k = z_A_k((6*T)+1 : 12*T);
        case 3
            u_A_d_k = u_A_k((12*T)+1 : 18*T);
            z_A_d_k = z_A_k((12*T)+1 : 18*T);
        case 4
            u_A_d_k = u_A_k((18*T)+1 :24*T);
            z_A_d_k = z_A_k((18*T)+1 :24*T);
        case 5
            u_A_d_k = u_A_k((24*T)+1 : 30*T);
            z_A_d_k = z_A_k((24*T)+1 : 30*T);
        case 6
            u_A_d_k = u_A_k((30*T)+1 : 36*T);
            z_A_d_k = z_A_k((30*T)+1 : 36*T);
    end
    
    % 10��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (4*T));
%             z_A_d_k = z_A_k(1 : (4*T));
%         case 2
%             u_A_d_k = u_A_k((4*T)+1 : 8*T);
%             z_A_d_k = z_A_k((4*T)+1 : 8*T);
%         case 3
%             u_A_d_k = u_A_k((8*T)+1 : 12*T);
%             z_A_d_k = z_A_k((8*T)+1 : 12*T);
%         case 4
%             u_A_d_k = u_A_k((12*T)+1 :16*T);
%             z_A_d_k = z_A_k((12*T)+1 :16*T);
%         case 5
%             u_A_d_k = u_A_k((16*T)+1 : 20*T);
%             z_A_d_k = z_A_k((16*T)+1 : 20*T);
%         case 6
%             u_A_d_k = u_A_k((20*T)+1 : 24*T);
%             z_A_d_k = z_A_k((20*T)+1 : 24*T);
%         case 7
%             u_A_d_k = u_A_k((24*T)+1 : 27*T);
%             z_A_d_k = z_A_k((24*T)+1 : 27*T);
%         case 8
%             u_A_d_k = u_A_k((27*T)+1 :30*T);
%             z_A_d_k = z_A_k((27*T)+1 :30*T);
%         case 9
%             u_A_d_k = u_A_k((30*T)+1 : 33*T);
%             z_A_d_k = z_A_k((30*T)+1 : 33*T);
%         case 10
%             u_A_d_k = u_A_k((33*T)+1 : 36*T);
%             z_A_d_k = z_A_k((33*T)+1 : 36*T);
%     end
%     
else%118
    % 1��
%     switch d
%         case 1
%             u_A_d_k= u_A_k(1 : (172*T));
%             z_A_d_k= z_A_k(1 : (172*T));
%     end
 % 3��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (61*T));
%             z_A_d_k = z_A_k(1 : (61*T));
%         case 2
%             u_A_d_k = u_A_k(61*T+1 : 129*T);
%             z_A_d_k = z_A_k(61*T+1 : 129*T);
%         case 3
%             u_A_d_k = u_A_k(129*T+1 : 172*T);
%             z_A_d_k = z_A_k(129*T +1: 172*T);
%     end
    % 5��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (23*T));
%             z_A_d_k = z_A_k(1 : (23*T));
%         case 2
%             u_A_d_k = u_A_k(23*T+1 : 61*T);
%             z_A_d_k = z_A_k(23*T+1 : 61*T);
%         case 3
%             u_A_d_k = u_A_k(61*T+1 : 103*T);
%             z_A_d_k = z_A_k(61*T+1 : 103*T);
%         case 4
%             u_A_d_k = u_A_k(103*T+1 : 145*T);
%             z_A_d_k = z_A_k(103*T+1 : 145*T);
%         case 5
%             u_A_d_k = u_A_k(145*T+1 : 172*T);
%             z_A_d_k = z_A_k(145*T+1 : 172*T);
%     end
    % 10��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (13*T));
%             z_A_d_k = z_A_k(1 : (13*T));
%         case 2
%             u_A_d_k = u_A_k(13*T+1 : 23*T);
%             z_A_d_k = z_A_k(13*T+1 : 23*T);
%         case 3
%             u_A_d_k = u_A_k(23*T+1 : 47*T);
%             z_A_d_k = z_A_k(23*T+1 : 47*T);
%         case 4
%             u_A_d_k = u_A_k(47*T+1 : 61*T);
%             z_A_d_k = z_A_k(47*T+1 : 61*T);
%         case 5
%             u_A_d_k = u_A_k(61*T+1 : 82*T);
%             z_A_d_k = z_A_k(61*T+1 : 82*T);
%         case 6
%             u_A_d_k = u_A_k(82*T+1 : 103*T);
%             z_A_d_k = z_A_k(82*T+1 : 103*T);
%         case 7
%             u_A_d_k = u_A_k(103*T+1 : 129*T);
%             z_A_d_k = z_A_k(103*T+1 : 129*T);
%         case 8
%             u_A_d_k = u_A_k(129*T+1 : 145*T);
%             z_A_d_k = z_A_k(129*T+1 : 145*T);
%         case 9
%             u_A_d_k = u_A_k(145*T+1 : 155*T);
%             z_A_d_k = z_A_k(145*T+1 : 155*T);
%         case 10
%             u_A_d_k = u_A_k(155*T+1 : 172*T);
%             z_A_d_k = z_A_k(155*T+1 : 172*T);
%     end
    
%     % 18��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (12*T));
%             z_A_d_k = z_A_k(1 : (12*T));
%         case 2
%             u_A_d_k = u_A_k(12*T+1 : 23*T);
%             z_A_d_k = z_A_k(12*T+1 : 23*T);
%         case 3
%             u_A_d_k = u_A_k(23*T+1 : 32*T);
%             z_A_d_k = z_A_k(23*T+1 : 32*T);
%         case 4
%             u_A_d_k = u_A_k(32*T+1 : 41*T);
%             z_A_d_k = z_A_k(32*T+1 : 41*T);
%         case 5
%             u_A_d_k = u_A_k(41*T+1 : 51*T);
%             z_A_d_k = z_A_k(41*T+1 : 51*T);
%         case 6
%             u_A_d_k = u_A_k(51*T+1 : 61*T);
%             z_A_d_k = z_A_k(51*T+1 : 61*T);
%         case 7
%             u_A_d_k = u_A_k(61*T+1 : 69*T);
%             z_A_d_k = z_A_k(61*T+1 : 69*T);
%         case 8
%             u_A_d_k = u_A_k(69*T+1 : 82*T);
%             z_A_d_k = z_A_k(69*T+1 : 82*T);
%         case 9
%             u_A_d_k = u_A_k(82*T+1 : 90*T);
%             z_A_d_k = z_A_k(82*T+1 : 90*T);
%         case 10
%             u_A_d_k = u_A_k(90*T+1 : 99*T);
%             z_A_d_k = z_A_k(90*T+1 : 99*T);
%         case 11
%             u_A_d_k = u_A_k(99*T+1 : 110*T);
%             z_A_d_k = z_A_k(99*T+1 : 110*T);
%         case 12
%             u_A_d_k = u_A_k(110*T+1 : 119*T);
%             z_A_d_k = z_A_k(110*T+1 : 119*T);
%         case 13
%             u_A_d_k = u_A_k(119*T+1 : 129*T);
%             z_A_d_k = z_A_k(119*T+1 : 129*T);
%         case 14
%             u_A_d_k = u_A_k(129*T+1 : 135*T);
%             z_A_d_k = z_A_k(129*T+1 : 135*T);
%         case 15
%             u_A_d_k = u_A_k(135*T+1 : 147*T);
%             z_A_d_k = z_A_k(135*T+1 : 147*T);
%         case 16
%             u_A_d_k = u_A_k(147*T+1 : 153*T);
%             z_A_d_k = z_A_k(147*T+1 : 153*T);
%         case 17
%             u_A_d_k = u_A_k(153*T+1 : 162*T);
%             z_A_d_k = z_A_k(153*T+1 : 162*T);
%         case 18
%             u_A_d_k = u_A_k(162*T+1 : 172*T);
%             z_A_d_k = z_A_k(162*T+1 : 172*T);
%     end
%     
    % 31��
%     switch d
%         case 1
%             u_A_d_k = u_A_k(1 : (5*T));
%             z_A_d_k = z_A_k(1 : (5*T));
%         case 2
%             u_A_d_k = u_A_k(5*T+1 : 11*T);
%             z_A_d_k = z_A_k(5*T+1 : 11*T);
%         case 3
%             u_A_d_k = u_A_k(11*T+1 : 16*T);
%             z_A_d_k = z_A_k(11*T+1 : 16*T);
%         case 4
%             u_A_d_k = u_A_k(16*T+1 : 21*T);
%             z_A_d_k = z_A_k(16*T+1 : 21*T);
%         case 5
%             u_A_d_k = u_A_k(21*T+1 : 27*T);
%             z_A_d_k = z_A_k(21*T+1 : 27*T);
%         case 6
%             u_A_d_k = u_A_k(27*T+1 : 32*T);
%             z_A_d_k = z_A_k(27*T+1 : 32*T);
%         case 7
%             u_A_d_k = u_A_k(32*T+1 : 39*T);
%             z_A_d_k = z_A_k(32*T+1 : 39*T);
%         case 8
%             u_A_d_k = u_A_k(39*T+1 : 44*T);
%             z_A_d_k = z_A_k(39*T+1 : 44*T);
%         case 9
%             u_A_d_k = u_A_k(44*T+1 : 51*T);
%             z_A_d_k = z_A_k(44*T+1 : 51*T);
%         case 10
%             u_A_d_k = u_A_k(51*T+1 : 56*T);
%             z_A_d_k = z_A_k(51*T+1 : 56*T);
%         case 11
%             u_A_d_k = u_A_k(56*T+1 : 62*T);
%             z_A_d_k = z_A_k(56*T+1 : 62*T);
%         case 12
%             u_A_d_k = u_A_k(62*T+1 : 68*T);
%             z_A_d_k = z_A_k(62*T+1 : 68*T);
%         case 13
%             u_A_d_k = u_A_k(68*T+1 : 73*T);
%             z_A_d_k = z_A_k(68*T+1 : 73*T);
%         case 14
%             u_A_d_k = u_A_k(73*T+1 : 78*T);
%             z_A_d_k = z_A_k(73*T+1 : 78*T);
%         case 15
%             u_A_d_k = u_A_k(78*T+1 : 83*T);
%             z_A_d_k = z_A_k(78*T+1 : 83*T);
%         case 16
%             u_A_d_k = u_A_k(83*T+1 : 88*T);
%             z_A_d_k = z_A_k(83*T+1 : 88*T);
%         case 17
%             u_A_d_k = u_A_k(88*T+1 : 95*T);
%             z_A_d_k = z_A_k(88*T+1 : 95*T);
%         case 18
%             u_A_d_k = u_A_k(95*T+1 : 100*T);
%             z_A_d_k = z_A_k(95*T+1 : 100*T);
%         case 19
%             u_A_d_k = u_A_k(100*T+1 : 106*T);
%             z_A_d_k = z_A_k(100*T+1 : 106*T);
%         case 20
%             u_A_d_k = u_A_k(106*T+1 : 112*T);
%             z_A_d_k = z_A_k(106*T+1 : 112*T);
%         case 21
%             u_A_d_k = u_A_k(112*T+1 : 119*T);
%             z_A_d_k = z_A_k(112*T+1 : 119*T);
%         case 22
%             u_A_d_k = u_A_k(119*T+1 : 123*T);
%             z_A_d_k = z_A_k(119*T+1 : 123*T);
%         case 23
%             u_A_d_k = u_A_k(123*T+1 : 129*T);
%             z_A_d_k = z_A_k(123*T+1 : 129*T);
%         case 24
%             u_A_d_k = u_A_k(129*T+1 : 134*T);
%             z_A_d_k = z_A_k(129*T+1 : 134*T);
%         case 25
%             u_A_d_k = u_A_k(134*T+1 : 138*T);
%             z_A_d_k = z_A_k(134*T+1 : 138*T);
%         case 26
%             u_A_d_k = u_A_k(138*T+1 : 142*T);
%             z_A_d_k = z_A_k(138*T+1 : 142*T);
%         case 27
%             u_A_d_k = u_A_k(142*T+1 : 146*T);
%             z_A_d_k = z_A_k(142*T+1 : 146*T);
%         case 28
%             u_A_d_k = u_A_k(146*T+1 : 152*T);
%             z_A_d_k = z_A_k(146*T+1 : 152*T);
%         case 29
%             u_A_d_k = u_A_k(152*T+1 : 158*T);
%             z_A_d_k = z_A_k(152*T+1 : 158*T);
%         case 30
%             u_A_d_k = u_A_k(158*T+1 : 165*T);
%             z_A_d_k = z_A_k(158*T+1 : 165*T);
%         case 31
%             u_A_d_k = u_A_k(165*T+1 : 172*T);
%             z_A_d_k = z_A_k(165*T+1 : 172*T);
%     end
%     
    %48��
    switch d
        case 1
            u_A_d_k = u_A_k(1 : (5*T));
            z_A_d_k = z_A_k(1 : (5*T));
        case 2
            u_A_d_k = u_A_k(5*T+1 : 8*T);
            z_A_d_k = z_A_k(5*T+1 : 8*T);
        case 3
            u_A_d_k = u_A_k(8*T+1 : 11*T);
            z_A_d_k = z_A_k(8*T+1 : 11*T);
        case 4
            u_A_d_k = u_A_k(11*T+1 : 14*T);
            z_A_d_k = z_A_k(11*T+1 : 14*T);
        case 5
            u_A_d_k = u_A_k(14*T+1 : 19*T);
            z_A_d_k = z_A_k(14*T+1 : 19*T);
        case 6
            u_A_d_k = u_A_k(19*T+1 : 23*T);
            z_A_d_k = z_A_k(19*T+1 : 23*T);
        case 7
            u_A_d_k = u_A_k(23*T+1 : 27*T);
            z_A_d_k = z_A_k(23*T+1 : 27*T);
        case 8
            u_A_d_k = u_A_k(27*T+1 : 30*T);
            z_A_d_k = z_A_k(27*T+1 : 30*T);
        case 9
            u_A_d_k = u_A_k(30*T+1 : 35*T);
            z_A_d_k = z_A_k(30*T+1 : 35*T);
        case 10
            u_A_d_k = u_A_k(35*T+1 : 39*T);
            z_A_d_k = z_A_k(35*T+1 : 39*T);
        case 11
            u_A_d_k = u_A_k(39*T+1 : 43*T);
            z_A_d_k = z_A_k(39*T+1 : 43*T);
        case 12
            u_A_d_k = u_A_k(43*T+1 : 46*T);
            z_A_d_k = z_A_k(43*T+1 : 46*T);
        case 13
            u_A_d_k = u_A_k(46*T+1 : 49*T);
            z_A_d_k = z_A_k(46*T+1 : 49*T);
        case 14
            u_A_d_k = u_A_k(49*T+1 : 52*T);
            z_A_d_k = z_A_k(49*T+1 : 52*T);
        case 15
            u_A_d_k = u_A_k(52*T+1 : 56*T);
            z_A_d_k = z_A_k(52*T+1 : 56*T);
        case 16
            u_A_d_k = u_A_k(56*T+1 : 60*T);
            z_A_d_k = z_A_k(56*T+1 : 60*T);
        case 17
            u_A_d_k = u_A_k(60*T+1 : 66*T);
            z_A_d_k = z_A_k(60*T+1 : 66*T);
        case 18
            u_A_d_k = u_A_k(66*T+1 : 69*T);
            z_A_d_k = z_A_k(66*T+1 : 69*T);
        case 19
            u_A_d_k = u_A_k(69*T+1 : 72*T);
            z_A_d_k = z_A_k(69*T+1 : 72*T);
        case 20
            u_A_d_k = u_A_k(72*T+1 : 76*T);
            z_A_d_k = z_A_k(72*T+1 : 76*T);
        case 21
            u_A_d_k = u_A_k(76*T+1 : 80*T);
            z_A_d_k = z_A_k(76*T+1 : 80*T);
        case 22
            u_A_d_k = u_A_k(80*T+1 : 83*T);
            z_A_d_k = z_A_k(80*T+1 : 83*T);
        case 23
            u_A_d_k = u_A_k(83*T+1 : 86*T);
            z_A_d_k = z_A_k(83*T+1 : 86*T);
        case 24
            u_A_d_k = u_A_k(86*T+1 : 89*T);
            z_A_d_k = z_A_k(86*T+1 : 89*T);
        case 25
            u_A_d_k = u_A_k(89*T+1 : 92*T);
            z_A_d_k = z_A_k(89*T+1 : 92*T);
        case 26
            u_A_d_k = u_A_k(92*T+1 : 95*T);
            z_A_d_k = z_A_k(92*T+1 : 95*T);
        case 27
            u_A_d_k = u_A_k(95*T+1 : 98*T);
            z_A_d_k = z_A_k(95*T+1 : 98*T);
        case 28
            u_A_d_k = u_A_k(98*T+1 : 101*T);
            z_A_d_k = z_A_k(98*T+1 : 101*T);
        case 29
            u_A_d_k = u_A_k(101*T+1 : 104*T);
            z_A_d_k = z_A_k(101*T+1 : 104*T);
        case 30
            u_A_d_k = u_A_k(104*T+1 : 109*T);
            z_A_d_k = z_A_k(104*T+1 : 109*T);
        case 31
            u_A_d_k = u_A_k(109*T+1 : 112*T);
            z_A_d_k = z_A_k(109*T+1 : 112*T);
        case 32
            u_A_d_k = u_A_k(112*T+1 : 115*T);
            z_A_d_k = z_A_k(112*T+1 : 115*T);
        case 33
            u_A_d_k = u_A_k(115*T+1 : 119*T);
            z_A_d_k = z_A_k(115*T+1 : 119*T);
        case 34
            u_A_d_k = u_A_k(119*T+1 : 122*T);
            z_A_d_k = z_A_k(119*T+1 : 122*T);
        case 35
            u_A_d_k = u_A_k(122*T+1 : 125*T);
            z_A_d_k = z_A_k(122*T+1 : 125*T);
        case 36
            u_A_d_k = u_A_k(125*T+1 : 128*T);
            z_A_d_k = z_A_k(125*T+1 : 128*T);
        case 37
            u_A_d_k = u_A_k(128*T+1 : 131*T);
            z_A_d_k = z_A_k(128*T+1 : 131*T);
        case 38
            u_A_d_k = u_A_k(131*T+1 : 136*T);
            z_A_d_k = z_A_k(131*T+1 : 136*T);
        case 39
            u_A_d_k = u_A_k(136*T+1 : 140*T);
            z_A_d_k = z_A_k(136*T+1 : 140*T);
        case 40
            u_A_d_k = u_A_k(140*T+1 : 144*T);
            z_A_d_k = z_A_k(140*T+1 : 144*T);
        case 41
            u_A_d_k = u_A_k(144*T+1 : 147*T);
            z_A_d_k = z_A_k(144*T+1 : 147*T);
        case 42
            u_A_d_k = u_A_k(147*T+1 : 150*T);
            z_A_d_k = z_A_k(147*T+1 : 150*T);
        case 43
            u_A_d_k = u_A_k(150*T+1 : 153*T);
            z_A_d_k = z_A_k(150*T+1 : 153*T);
        case 44
            u_A_d_k = u_A_k(153*T+1 : 156*T);
            z_A_d_k = z_A_k(153*T+1 : 156*T);
        case 45
            u_A_d_k = u_A_k(156*T+1 : 159*T);
            z_A_d_k = z_A_k(156*T+1 : 159*T);
        case 46
            u_A_d_k = u_A_k(159*T+1 : 162*T);
            z_A_d_k = z_A_k(159*T+1 : 162*T);
        case 47
            u_A_d_k = u_A_k(162*T+1 : 168*T);
            z_A_d_k = z_A_k(162*T+1 : 168*T);
        case 48
            u_A_d_k = u_A_k(168*T+1 : 172*T);
            z_A_d_k = z_A_k(168*T+1 : 172*T);
    end
 
    
end


end

